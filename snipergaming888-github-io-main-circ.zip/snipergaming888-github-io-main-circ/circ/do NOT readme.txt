 ,ggggggggggg,                                                                                         d8'      
dP"""88""""""Y8,                         ,dPYb,                                                  8I   d8'       
Yb,  88      `8b                         IP'`Yb                                                  8I  ""         
 `"  88      ,8P                         I8  8I              gg                                  8I             
     88aaaad8P"                          I8  8'              ""                                  8I             
     88""""Y8ba    ,ggggg,    gg     gg  I8 dP    ,gggggg,   gg    ,ggg,    ,ggg,,ggg,     ,gggg,8I      ,g,    
     88      `8b  dP"  "Y8ggg I8     8I  I8dP     dP""""8I   88   i8" "8i  ,8" "8P" "8,   dP"  "Y8I     ,8'8,   
     88      ,8P i8'    ,8I   I8,   ,8I  I8P     ,8'    8I   88   I8, ,8I  I8   8I   8I  i8'    ,8I    ,8'  Yb  
     88_____,d8',d8,   ,d8'  ,d8b, ,d8I ,d8b,_  ,dP     Y8,_,88,_ `YbadP' ,dP   8I   Yb,,d8,   ,d8b,  ,8'_   8) 
    88888888P"  P"Y8888P"    P""Y88P"888PI8"88888P      `Y88P""Y8888P"Y8888P'   8I   `Y8P"Y8888P"`Y8  P' "YY8P8P
                                   ,d8I' I8 `8,                                                                 
                                 ,dP'8I  I8  `8,                                                                
                                ,8"  8I  I8   8I                                                                
                                I8   8I  I8   8I                                                                
                                `8, ,8I  I8, ,8'                                                                
                                 `Y8P"    "Y8P'                                                                 
     ,gggg,                                                                                                     
   ,88"""Y8b,                                        ,dPYb,               I8                                    
  d8"     `Y8                                        IP'`Yb               I8                                    
 d8'   8b  d8  gg                                    I8  8I            88888888  gg                             
,8I    "Y88P'  ""                                    I8  8'               I8     ""                             
I8'            gg    ,gggggg,    ,gggg,  gg      gg  I8 dP    ,gggg,gg    I8     gg     ,ggggg, ,ggg,,ggg,  
d8             88    dP""""8I   dP"  "Yb I8      8I  I8dP    dP"  "Y8I    I8     88    dP"  "Y8g8" "8P" "8, 
Y8,            88   ,8'    8I  i8'       I8,    ,8I  I8P    i8'    ,8I   ,I8,    88   i8'    ,8I    8I   8I 
`Yba,,_____, _,88,_,dP     Y8,,d8,_    _,d8b,  ,d8b,,d8b,_ ,d8,   ,d8b, ,d88b, _,88,_,d8,   ,d8'    8I   Yb,
  `"Y8888888 8P""Y88P      `Y8P""Y8888PP8P'"Y88P"`Y88P'"Y88P"Y8888P"`Y888P""Y888P""Y8P"Y8888P"      8I   `Y8
                                                                                                                
#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-

Hello! Welcome to Xeneth's "Boyfriend's Circulation" mod! After Sketchy I took a break and decided to just relax a little.
Well now I'm back with a brand new mod with music from an anime I don't watch! (Beat that one, nerds!)

Special thanks to:

Haley - Made the backgrounds
Gabe (Whippy Orc) - Charting
PlushtrapDev - Additional Charting
Sulayre - Sulayre

While you're still here, donate to Ninjamuffin's kickstarter campaign!
kickstarter.com/projects/funkin/friday-night-funkin-the-full-ass-game

Thanks!
- Xeneth (I don't watch anime)

P.S.
    I do not own the rights to "Renai Circulation" by Kana Hanazawa, however I did make the version
    that's in the mod, which you can find on my soundcloud: https://soundcloud.com/xeneth-sc/boyfriends-circulation
#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#



#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#- 
Original readme file
#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-                               
 __
/ _   _ |_ |_ .  _                                     
\__) (- |_ |_ | | )                                    
                                                       
 __                                                    
|_   _  _  _  |                                        
|   |  (- (_| |( \/                                    
                 /                                     
                                                       
 _   _     _                                           
(_) | )   (_|                                          
                                                       
 __                                                    
|_   _ .  _|  _        _  .  _  |_  |_       _  _  |_  
|   |  | (_| (_| \/   | ) | (_) | ) |_   \/ (- (_| | ) 
                 /          _/           /             

HEY
Thanks for downloadin Friday Night FUNKIN'
If you downloaded this from any other place than ninja-muffin24.itch.io/FUNKIN
You might be in DANGER!!! 

The Itch.io release is the only official source for the desktop (PC, Mac, Linux) versions of the game!
As of right now, the game is FREE! If you paid for it, you got SCAMMED!

Now that that's out of the way....
THANKS FOR DOWNLOADIN. 

#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-
    PERMISSIONS XDDDD
#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-

Little info, you have FULL PERMISSION to stream, letsplay, meme, shitpost, do WHATEVER you want with the game.
Use the music in videos you do, use art, ANYTHING. GO CRAZY BRO.

If you do make any sort of video, it would be a bro move if you linked the game and spread the word

Play On Newgrounds - https://www.newgrounds.com/portal/view/770371
Support on Itch.io - https://ninja-muffin24.itch.io/funkin

If not no biggie we don't fully hate you only kinda no biggie.


#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-
    INFO AND LINKS
#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-

If you wanna dig around, the game is fully open source on Github
https://github.com/ninjamuffin99/Funkin

It's made in Haxe / HaxeFlixel

MUSIC IS ON SPOTIFY AND BANDCAMP AND EVERYWHERE ELSE PROB TOO
https://kawaisprite.bandcamp.com/album/friday-night-funkin-ost-vol-1


#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-
    FINAL WORDS / CREDITS
#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-#-

Friday Night Funkin' is made by ninjamuffin99 (programmer), PhantomArcade (animator), kawaisprite (musician), and evilsk8r (artist)

https://twitter.com/ninja_muffin99
https://twitter.com/phantomarcade3k
https://twitter.com/kawaisprite
https://twitter.com/evilsk8r

Pico is created by Tom Fulp
Skid and Pump are created by SrPelo
BassetFilms did music for lemon monster songs


Final important thing, this is made with the support and love to and from Newgrounds.com.
Go to newgrounds, we love newgrounds. newgrounds good. How many times do I gotta damn say it. Newgrounds newgrounds newgrounds newgrounds
I love Tom Fulp.

- Cameron ♪(´▽｀)

##################################################################################
                                                                                  
 _   _   _____   _      _    ____   ____     ___    _   _   _   _   ____    ____  
| \ | | | ____| | |    | |  / ___| |  _ \   / _ \  | | | | | \ | | |  _ \  / ___| 
|  \| | |  _|   | | /\ | | | |  _  | |_) | | | | | | | | | |  \| | | | | | \___ \ 
| |\  | | |___   \ V  V /  | |_| | |  _ <  | |_| | | |_| | | |\  | | |_| |  ___) |
|_| \_| |_____|   \_/\_/    \____| |_| \_\  \___/   \___/  |_| \_| |____/  |____/ 
 _       _  _     ___    ___       __              _       _  _       _        _  
|_ |  | |_ |_) \_/ | |_|  |  |\ | /__     |_      |_ |  | |_ |_) \_/ / \ |\ | |_  
|_  \/  |_ | \  |  | | | _|_ | \| \_| o   |_)\/   |_  \/  |_ | \  |  \_/ | \| |_ o
                                      /      /                                    
                                                                                  
##################################################################################