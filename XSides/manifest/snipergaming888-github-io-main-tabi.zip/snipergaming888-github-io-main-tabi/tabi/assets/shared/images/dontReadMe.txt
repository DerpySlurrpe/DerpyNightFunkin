guys its me gwebdev
ya i suffered trying to get this fire shit to work lol
hope u LIKE it
;-;
well its more of code and crap
i dont make art