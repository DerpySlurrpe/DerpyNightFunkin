hey its me gwebdev
just wanted to tell u i enhanced dialogues
well its now called
the
GTEDF
or
GWebDev's
Tabi
Enhanced
Dialogue
Format
idk why the fuck i came up with that
and i dont care
anyhow
the usage is pretty simple
(its not)
lol
but uh
:enableTypeSound: :disableTypeSound:
enable and disable the typing sound
:switchSound:(sound path)
this uh change typing sound to that
:sound:(fuckumate)
that plays a sound
:soundoverwrite:(path again)
this makes a sound variable
that can be overwritten
if u put another one of that
in short terms its called
if soundoverwrite this
and after this dialogue
soundoverwrite again
cancel the last one 
lol
while in sound
it doesnt...
it cant be overwritten
u get the point
:makeGraphic:alpha,red,green,blue
255 max value of this one
u can put alpha red green and blue
all 255 max value
this changes bg to a color
and uh
:bghide:
yes
literally bghide
no parameters
it just hides the background
:bg:(uhhhhh)
loads an image as a background...
:class:(classname),(parameters thats uh use comma)
for example
:class:PlayState,2,4,5,2,1,5,a string
but uhm
u cant make a class
that just loads one
so class is pretty useless
u can just switch between cutscene classes
Cutscene1
and
Cutscene2
they are hardcoded in game
Cutscene1 is my battle cutscene
Cutscene2 is genocide cutscene
and yes
then if u wanna call the class to use
:class-use:(classname)
to use the class
NOW lol
i recommend putting :class: in the start
since loading the Cutscenes take time
so yes lol
then last commands
:fadeIn:(time in seconds)
:fadeOut:(time in seconds)
and umm if u wanna change the fade uh color
:fadeColor:alpha,red,green,blue
u know
same as makegraphic format
lol
theres also music shit
:musicloop:(music path)
:music:(music path)
:musicstop:
musicloop plays looped music (like fire effects for example)
music just plays music
musicstop (u guessed it) it stops all music lol
u can stop soundoverwrite without sound by doing soundoverwritestop too
:chromeoffset:
this is the uh chromatic aberration offset (only works when photosensitive mode is off)

the dialogues are separated to 4 sections
they start with
---SECTION START---
and end with
---SECTION END---
section 1 triggers only when normal
section 2 triggers only when voicelines are on
sectoin 3 triggers when russian dialogues are on
section 4 triggers when voicelines and russian dialogues are on

and uh
the characters u can use are

tabi
tabi-worried
tabi-mad

gf
gf-hmm
gf-talking

bf-right
bf-left
bf-exp (on genocide)

noone (no character lol only speech bubble shows)

thats all for the GTEDF
thank you :)